const apiURL = 'http://localhost:3000'

export {apiURL}